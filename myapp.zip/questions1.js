let ozi = {
    "response_code": 0,
    "results": [
        {
            "category": "General Knowledge",
            "type": "multiple",
            "difficulty": "easy",
            "question": "?גלו מי הילד הכי קטן בכיתה שעבר לרמת גן וחי בה עד מותו",
            "correct_answer": "עוזי חיטמן",
            "incorrect_answers": [
                "שלמה ארצי",
                "ביאליק",
                "משה אביב"
            ]
        },
        {
            "category": "General Knowledge",
            "type": "multiple",
            "difficulty": "easy",
            "question": "?מה הסגנון המוזיקה של עוזי חיטמן",
            "correct_answer": "כל התשובות נכונות",
            "incorrect_answers": [
                "מוזיקת פופ",
                "שירי ילדים",
                "שירי ארץ ישראל"
            ]
        },
        {
            "category": "General Knowledge",
            "type": "multiple",
            "difficulty": "easy",
            "question": ":בשנת 2001 עוזי חיטמן קיבל את פרס",
            "correct_answer": "פרס נוצת הזהב",
            "incorrect_answers": [
                "פרס ישרא",
                "פרס הצבר המוביל",
                "פרס הזמר העברי"
            ]
        },
        {
            "category": "General Knowledge",
            "type": "multiple",
            "difficulty": "easy",
            "question": "?מה היה עוזי חיטמן",
            "correct_answer": "כל התשובות נכונות",
            "incorrect_answers": [
                "זמר",
                "פזמונאי",
                "מנחה טלווזיה ישראלית"
            ]
        }
    ]
}