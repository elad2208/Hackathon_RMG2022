let shlomo = {
    "response_code": 0,
    "results": [
        {
            "category": "General Knowledge",
            "type": "multiple",
            "difficulty": "easy",
            "question": "?באיזו שנה זכה שלמה ארצי בפסטיבל הזמר והפזמון",
            "correct_answer": "1970",
            "incorrect_answers": [
                "1991",
                "1989",
                "1971"
            ]
        },
        {
            "category": "General Knowledge",
            "type": "multiple",
            "difficulty": "easy",
            "question": "?מה שם השיר שמופיע על הגרפיטי",
            "correct_answer": "לא עוזב את העיר",
            "incorrect_answers": [
                "היא לא יודעת מה עובר עלי",
                "מלך העולם",
                "פעם תורי ופעם תורך"
            ]
        },
        {
            "category": "General Knowledge",
            "type": "multiple",
            "difficulty": "easy",
            "question": "?באיזה פרס זכה שלמה ארצי בשנת 1970",
            "correct_answer": "פרס כינור דוד",
            "incorrect_answers": [
                "פרס הזמר העברי",
                "פרס ישראל",
                "פרס אביטל"
            ]
        },
        {
            "category": "General Knowledge",
            "type": "multiple",
            "difficulty": "easy",
            "question": "?מי בנולד באלוני אבא",
            "correct_answer": "שלמה ארצי",
            "incorrect_answers": [
                "עומר אדם",
                "עוזי חיטמן",
                "גיל אלון"
            ]
        }
    ]
}